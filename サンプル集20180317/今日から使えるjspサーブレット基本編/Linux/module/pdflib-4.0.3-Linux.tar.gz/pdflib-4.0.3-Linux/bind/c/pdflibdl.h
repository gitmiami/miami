/*---------------------------------------------------------------------------*
 |           PDFlib - A library for generating PDF on the fly                |
 +---------------------------------------------------------------------------+
 |          Copyright (c) 1997-2002 PDFlib GmbH. All rights reserved.        |
 *---------------------------------------------------------------------------*/

/* $Id: pdflibdl.h,v 1.1.2.2 2002/05/29 15:07:37 tm Exp $
 *
 * Function prototypes for dynamically loading the PDFlib DLL at runtime
 *
 */

#ifdef __cplusplus
#define PDF PDF_c
#endif

#include "pdflib.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Load the PDFlib DLL, and fetch pointers to all exported functions. */
PDFLIB_API PDFlib_api * PDFLIB_CALL
PDF_boot_dll(void);

/* Unload the previously loaded PDFlib DLL  (also calls PDF_shutdown()) */
PDFLIB_API void PDFLIB_CALL
PDF_shutdown_dll(PDFlib_api *pdflib);

#ifdef __cplusplus
}	/* extern "C" */
#endif
