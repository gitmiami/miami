﻿window.onload = function() {
	var hMenu1 = new Spry.Widget.MenuBar("MenuBar1");
}
