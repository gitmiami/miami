﻿window.onload = function() {
	var accObj1 = new Spry.Widget.Accordion("Accordion1");
}
