﻿window.onload = function() {
	var accObj1 = new Spry.Widget.CollapsiblePanel("CollapsiblePanel1");
	var accObj2 = new Spry.Widget.CollapsiblePanel("CollapsiblePanel2", { contentIsOpen:false });
}
