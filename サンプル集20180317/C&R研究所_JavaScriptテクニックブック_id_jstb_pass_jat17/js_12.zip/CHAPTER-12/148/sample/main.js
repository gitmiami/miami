﻿window.onload = function(){
	new Control.ColorPicker("colorfield", { IMAGE_BASE : "img/" });
}
