﻿dojo.require("dojo.widget.Wizard");

function done() {
	alert("次はiPodを接続します");
}
