﻿window.onload = function() {
	var tbObj1 = new Spry.Widget.TabbedPanels("tabPanel1");
}
