﻿n = 0;
for(;;){
	n++;
	if (n>10) break;
}
alert(n);
