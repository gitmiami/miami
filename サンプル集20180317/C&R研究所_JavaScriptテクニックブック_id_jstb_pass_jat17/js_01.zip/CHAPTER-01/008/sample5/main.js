﻿n = 0;
i = 0;
while (i<10){
	n = n + i;
	i++;
}
alert(n);

