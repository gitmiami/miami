﻿n = 0;
for (i=0; i<10; i++) n = n + i;
alert(n);


