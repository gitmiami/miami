﻿n = 0;
m = 0;
for (i=0, j=1; i<10; i++, j++) { n = n + i; m = m + j; }
alert(n);
alert(m);

