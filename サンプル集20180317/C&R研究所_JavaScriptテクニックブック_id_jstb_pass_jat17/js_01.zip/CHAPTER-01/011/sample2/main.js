﻿window.onload = function(){
	document.getElementById("aLink").onclick = function(){
		alert("ok");
	}
}