﻿window.onload = function(){
	document.getElementById("aLink").onclick = function(){
		alert("NG");
	}
	document.getElementById("aLink").onclick = function(){
		alert("ok");
	}
}