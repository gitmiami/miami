﻿window.onload = function(){
	document.getElementById("aLink").onclick = function(evt){
		alert(evt);
		alert(event);
	}
}