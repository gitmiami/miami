﻿a = {
	"type":12,
	test : function(){ alert("test"); },
}
a.test();
