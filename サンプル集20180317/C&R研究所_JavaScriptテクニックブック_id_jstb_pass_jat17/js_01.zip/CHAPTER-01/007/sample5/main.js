﻿a = prompt("英文字を入れてください", "a");
switch(a){
	case "a" : alert("aです");
						break;
	case "b" : alert("bです");
						break;
	case "c" : alert("cです");
						break;
	default : alert("abc以外です");
}
