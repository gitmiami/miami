﻿var b = 9;
a = (b || 12);
alert(a);
