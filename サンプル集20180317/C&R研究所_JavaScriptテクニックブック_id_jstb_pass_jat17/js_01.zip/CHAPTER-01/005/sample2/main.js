﻿a = new Object();
a.year = 1969;
a.name = "KF";
alert(a.year);
alert(a.name);
