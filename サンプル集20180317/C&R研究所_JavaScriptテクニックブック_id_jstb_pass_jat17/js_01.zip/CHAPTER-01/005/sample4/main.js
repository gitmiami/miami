﻿a = { year : 1969, name : "KF" };
if ("year" in a) alert("プロパティは存在しています");
