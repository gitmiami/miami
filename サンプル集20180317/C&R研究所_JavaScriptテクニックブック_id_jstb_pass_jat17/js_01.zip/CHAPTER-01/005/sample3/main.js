﻿a = { year : 1969, name : "KF" };
for (key in a){
	alert(a[key]);
}