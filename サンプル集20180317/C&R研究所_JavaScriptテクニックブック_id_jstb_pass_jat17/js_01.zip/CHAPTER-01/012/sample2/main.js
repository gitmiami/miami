﻿window.onload = function(){
	document.images[0].src = "images/ok.jpg";
	document.im2.src = "images/ok.jpg";
	document.images["im3"].src = "images/ok.jpg";
}
