﻿window.onload = function(){
	document.body.style.backgroundColor = "yellow";
}
