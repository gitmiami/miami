﻿a = 12;
var b = 34;
function test(){
	c = 56;
	var d = 78;
}
