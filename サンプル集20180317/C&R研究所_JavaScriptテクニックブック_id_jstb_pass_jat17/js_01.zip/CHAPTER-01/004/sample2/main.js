﻿a = "OK";
alert(a);
alert(window.a);
