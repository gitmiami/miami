﻿window.onload = function(){
	document.getElementById("getButton1").onclick = function(){
		a = document.body.style;
		b = a;
		b.backgroundColor = "red";
	}
}
