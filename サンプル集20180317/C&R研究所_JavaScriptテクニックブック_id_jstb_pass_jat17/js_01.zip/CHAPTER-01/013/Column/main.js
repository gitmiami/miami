﻿YAHOO.namespace ("KF"); 
YAHOO.KF = function(){ alert("名前空間サンプル");}
YAHOO.KF();