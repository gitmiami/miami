﻿test = new Function("alert('ok')");
test();