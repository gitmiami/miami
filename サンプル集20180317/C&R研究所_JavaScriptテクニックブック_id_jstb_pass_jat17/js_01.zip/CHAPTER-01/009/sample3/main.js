﻿function abc(){ alert(123); }
abc();
window.abc();
