﻿String.prototype.star = function(){
	return "★"+this;
}
alert("Sample".star());
