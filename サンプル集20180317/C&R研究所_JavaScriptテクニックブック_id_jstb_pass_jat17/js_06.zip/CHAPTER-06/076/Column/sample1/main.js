﻿window.onload = function(){
	tbl = document.getElementById("table1");
	alert(tbl.firstChild.tagName);
}
