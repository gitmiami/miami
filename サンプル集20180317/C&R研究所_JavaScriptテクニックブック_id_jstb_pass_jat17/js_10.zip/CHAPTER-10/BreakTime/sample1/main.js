﻿window.onload = function(){
	tm1 = new Date();
	alert("少し待ってからOKボタンをクリック");
	tm2 = new Date();
	alert(tm2-tm1+"ミリ秒後にクリックされました");
}
