﻿window.onload = function(){
	document.getElementById("setButton1").onclick = function(){
		document.getElementById("cssMain").href = "main.css";
	}
	document.getElementById("setButton2").onclick = function(){
		document.getElementById("cssMain").href = "main2.css";
	}
}
