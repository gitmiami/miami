﻿window.onload = function(){
	document.getElementById("setButton1").onclick = function(){
		document.getElementById("result").className = "normal";
	}
	document.getElementById("setButton2").onclick = function(){
		document.getElementById("result").className = "caution";
	}
}
