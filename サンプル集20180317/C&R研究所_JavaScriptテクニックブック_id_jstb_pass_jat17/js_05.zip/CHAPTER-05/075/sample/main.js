﻿var dateObj = new Date();
var n = dateObj.getMonth() + 1;
window.open("pages/"+n+".html", "sbwin","width=480,height=320");
