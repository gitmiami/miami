﻿function testFunc(){
	alert("最初に定義した関数");
}
function testFunc(){
	alert("二番目に定義した関数");
}
testFunc();
