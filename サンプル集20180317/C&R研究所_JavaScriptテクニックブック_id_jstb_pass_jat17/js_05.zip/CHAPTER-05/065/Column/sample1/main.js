﻿window.onload = function(){
　　alert("Sample");
}
