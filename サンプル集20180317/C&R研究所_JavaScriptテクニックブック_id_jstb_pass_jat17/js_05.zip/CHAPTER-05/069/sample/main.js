﻿window.open("sub.html", "sbwin1","width=480,height=320");
