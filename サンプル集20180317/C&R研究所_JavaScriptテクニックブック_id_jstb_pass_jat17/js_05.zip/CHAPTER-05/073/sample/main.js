﻿window.onload = function(){
	Dialog.alert("部屋を明るくしてから御覧ください", {
		windowParameters: {width:320, height:100},
		okLabel: "はい"
	});
}
