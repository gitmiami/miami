﻿str1 = "Sample";
str2 = 'Sample';
