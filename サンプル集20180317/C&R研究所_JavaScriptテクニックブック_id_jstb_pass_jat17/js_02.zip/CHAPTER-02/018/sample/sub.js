﻿document.getElementById("checkButton").onclick = function(){
	document.getElementById("result").innerHTML = "今日もいい天気ですね！";
}
