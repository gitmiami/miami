﻿alert("sub2.jsです");
