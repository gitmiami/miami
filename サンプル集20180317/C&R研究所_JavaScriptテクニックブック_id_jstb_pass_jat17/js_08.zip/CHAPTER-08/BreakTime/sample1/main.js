﻿document.getElementById("result").innerHTML = "OK";
