﻿window.onload = function(){
	document.getElementById("result").innerHTML = "OK";
}
