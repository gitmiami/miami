﻿window.onload = function() {
	new Spry.Widget.ValidationTextField("checkData1", "url", {validateOn:["blur","change"]});
}
