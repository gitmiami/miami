﻿window.onload = function(){
	document.getElementById("jump").onchange = function(){
		location.href = this.value;
	}
}
