﻿window.onload = function() {
	new Spry.Widget.ValidationTextField("checkData1", "currency", {validateOn:["blur","change"]});
}
