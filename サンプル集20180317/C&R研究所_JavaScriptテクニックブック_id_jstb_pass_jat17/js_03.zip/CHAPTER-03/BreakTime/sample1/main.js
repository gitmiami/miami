﻿setInterval("(function (){ window.status = new Date })()", 1000);
