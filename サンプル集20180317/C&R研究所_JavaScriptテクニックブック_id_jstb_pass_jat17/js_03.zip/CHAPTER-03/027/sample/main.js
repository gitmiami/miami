﻿window.onload = function(){
	document.getElementById("userID").focus();
}
