﻿window.onload = function(){
	document.getElementById("userID").focus();
	document.getElementById("userID").select();
}
