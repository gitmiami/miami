﻿window.onload = function() {
	new Spry.Widget.ValidationTextField("checkData1", "real", {validateOn:["blur","change"]});
}
