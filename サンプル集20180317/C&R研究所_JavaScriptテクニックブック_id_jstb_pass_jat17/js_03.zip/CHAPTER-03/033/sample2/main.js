﻿window.onload = function() {
	new Spry.Widget.ValidationTextField("checkData1", "integer", {validateOn:["blur","change"]});
}
