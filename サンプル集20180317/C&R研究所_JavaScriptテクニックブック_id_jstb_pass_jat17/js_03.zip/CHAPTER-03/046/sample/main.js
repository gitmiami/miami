﻿window.onload = function(){
	document.getElementById("checkAccept").onclick = function(){
		document.getElementById("uMail").disabled = !this.checked;
	}
}
