﻿myDatabase = new Spry.Data.XMLDataSet("data.xml", "/list/fruits");
